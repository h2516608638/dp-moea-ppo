# DP-MOEA/PPO 独立 MATLAB 实现

本目录是 DP-MOEA/PPO 的独立 MATLAB 多文件版本，不依赖 PlatEMO 框架，自带 DTLZ1–DTLZ7
测试问题、进化算子、PPO（Proximal Policy Optimization）神经网络、外部种群（EP）维护、
权重自适应与 IGD/HV 指标。

## 运行方法

1. 用 MATLAB 打开本文件夹（或将本文件夹加入路径）。
2. 打开 `main.m`，在顶部“配置区”修改问题名（`dtlz1`–`dtlz7`）、目标数 `M`（2/3/5/8/10）
   与运行次数 `RUNS`。
3. 直接运行 `main.m`。结果（IGD 均值/标准差、`.mat` 与 `.csv`）输出到 `results/`。

## 工具箱依赖

- **Statistics and Machine Learning Toolbox**：仅权重自适应中的 Dirichlet 采样使用 `drnd`。
  距离计算（`pairwise_dist`，替代 `pdist2`）、手写神经网络的前向/反向传播、Adam、GAE 等
  均为基础 MATLAB 实现，不依赖任何工具箱。
- 若未安装该工具箱，可将 `drnd(alpha,n)` 替换为基于 `gamrnd` 的等价实现，或联系补充。
- 已在缺少统计工具箱的环境实跑验证：`smoke_test.m`（M=2 完整链路，含 PPO 更新与环境选择）
  与 `problem_unittest.m`（DTLZ1–7 的 M=2/3 目标函数与解析前沿）。

## 目录结构

```
main.m                 入口：配置、运行、汇总、保存
set_seed.m             随机种子
generate_population.m  初始种群
generate_weights.m     权重向量（Das-Dennis 单纯形点）
kmeans_simple.m        简易 KMeans
adapt_weights.m        权重自适应（删除/添加规则）
pairwise_dist.m        欧氏距离矩阵（纯基础 MATLAB）
igd_metric.m           IGD 指标
hv_monte_carlo.m       蒙特卡洛 HV 指标
cosine_angle.m         向量夹角
smoke_test.m           M=2 冒烟测试（无需统计工具箱）
problem_unittest.m     DTLZ 问题单元测试
@MOEAD_PPO/            主算法（handle 类，方法分文件）
@PPO/                  PPO 智能体
@MLP/                  全连接网络（手写前向/反向/Adam）
@PPOBuffer/            经验缓冲区（含 GAE）
@EP_Maintainer/        外部种群维护
@DTLZProblem/          DTLZ1–DTLZ7 问题与解析 Pareto 前沿
results/               输出目录
```

## 关键超参数（与论文一致）

- 状态 8 维、动作 3 维；动作边界 `[1,15,15]`，偏移 `[0,2,5]`。
- 前 100 代确定性热身；PPO 缓冲区 256、小批量 32、更新轮数 10、每 20 步更新一次；
  学习率 3e-4，折扣因子 0.99，GAE 参数 0.95，裁剪 0.2，梯度裁剪 0.5。
- 隐藏层 256；EP 容量 1.5N；权重自适应每 50 代，删除/添加角度阈值 8°/6°。
- 种群规模：M=2/3 为 100，M=5 为 126，M=8 为 156，M=10 为 275；最大代数 500。

## 说明与限制

- 本版本当前覆盖 **DTLZ1–DTLZ7**；WFG 系列因变换链较长暂未包含，可在后续按相同接口补充。
- 神经网络为手写矩阵运算实现，数值结果与 Python/PyTorch 版本在趋势上一致，但因随机流、
  浮点库不同，逐次数值不会完全相同。
- 已在缺少统计工具箱的环境实跑通过 M=2 完整算法链路与 DTLZ1–7（M=2/3）的目标函数/前沿。
  尚未在本机验证的部分：`drnd` 权重自适应（M≥3）、M≥5 的 epsilon 非支配排序分支、
  完整 500 代与标准种群规模。请在装有完整工具箱的 MATLAB 上运行 `main.m` 做最终确认；
  如遇报错请把完整报错信息发回。
