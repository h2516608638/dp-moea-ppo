function [scaled_action, value, log_prob] = select_action(obj, state, deterministic)
    % 根据状态选择动作，返回缩放后的动作、状态价值与对数概率
    % deterministic=true 时取均值动作，log_prob 返回 []（对应 Python 的 None）
    if nargin < 3, deterministic = false; end
    X = state(:);
    ad = obj.action_dim;

    out = obj.policy.forward(X);
    mean_v = out(1:ad);
    log_std = min(max(out(ad+1:end), -10), 1);
    std_v = exp(log_std);

    if deterministic
        z = mean_v;
        log_prob = [];
    else
        z = mean_v + std_v .* randn(ad, 1);
        log_prob = -0.5 * sum(((z - mean_v) ./ std_v).^2 ...
            + 2 * log_std + log(2*pi));
    end

    value = obj.value_net.forward(X);
    value = value(1);

    scaled_action = tanh(z) .* obj.action_scale + obj.action_bias;
    scaled_action = scaled_action(:).';   % 行向量
end
