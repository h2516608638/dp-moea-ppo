function store_transition(obj, state, action, reward, value, log_prob)
    % 存储一步交互；将缩放动作逆变换回 tanh 前的原始空间 z
    if any(isnan(state)) || any(isnan(action)) || isnan(reward) || isnan(value) ...
            || (~isempty(log_prob) && (isnan(log_prob) || isinf(log_prob)))
        warning('NaN detected in transition data');
        return
    end
    normalized = (action(:) - obj.action_bias) ./ obj.action_scale;
    normalized = min(max(normalized, -0.95), 0.95);
    z = atanh(normalized);
    obj.buffer.store(state(:).', z(:).', reward, value, log_prob);
end
