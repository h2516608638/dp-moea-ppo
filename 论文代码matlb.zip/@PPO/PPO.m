classdef PPO < handle
    % PPO  Proximal Policy Optimization（近端策略优化）智能体
    %   策略网络与价值网络由手写 MLP 实现，两个独立 Adam 优化器。
    properties
        state_dim
        action_dim
        action_scale          % 列向量 [action_dim,1]
        action_bias           % 列向量
        clip_ratio = 0.2
        value_coef = 0.5
        entropy_coef = 0.01
        batch_size = 32
        update_epochs = 10
        lr = 3e-4
        policy                % MLP，输出 2*action_dim（前半 mean，后半 log_std）
        value_net             % MLP，输出 1
        buffer                % PPOBuffer
    end

    methods
        function obj = PPO(state_dim, action_dim, action_bound, lr, gamma, lam, ...
                clip_ratio, buffer_size, batch_size, update_epochs)
            obj.state_dim = state_dim;
            obj.action_dim = action_dim;
            obj.action_scale = action_bound(:);
            obj.action_bias = zeros(action_dim, 1);
            if nargin >= 4 && ~isempty(lr), obj.lr = lr; end
            if nargin >= 7 && ~isempty(clip_ratio), obj.clip_ratio = clip_ratio; end
            if nargin >= 9 && ~isempty(batch_size), obj.batch_size = batch_size; end
            if nargin >= 10 && ~isempty(update_epochs), obj.update_epochs = update_epochs; end
            if nargin < 5 || isempty(gamma), gamma = 0.99; end
            if nargin < 6 || isempty(lam), lam = 0.95; end
            if nargin < 8 || isempty(buffer_size), buffer_size = 256; end

            h = 256;
            g2 = sqrt(2);
            obj.policy = MLP([state_dim, h, h, 2*action_dim], [g2, g2, 0.01]);
            obj.value_net = MLP([state_dim, h, h, 1], [g2, g2, 1.0]);
            obj.buffer = PPOBuffer(buffer_size, state_dim, action_dim, gamma, lam);
        end
    end
end
