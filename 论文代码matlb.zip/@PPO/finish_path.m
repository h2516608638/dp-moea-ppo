function finish_path(obj, last_value)
    obj.buffer.finish_path(last_value);
end
