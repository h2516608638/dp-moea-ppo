function info = update(obj)
    % 用缓冲区数据执行 PPO 更新，返回训练统计
    data = obj.buffer.get();
    if isempty(data)
        info = [];
        return
    end

    S     = data.states.';          % [state_dim, n]
    Zall  = data.actions.';         % [action_dim, n]（tanh 前原始动作）
    oldLP = data.log_probs(:);      % [n,1]
    oldV  = data.values(:);         % [n,1]
    rets  = data.returns(:);        % [n,1]
    adv   = data.advantages(:);     % [n,1]
    n = size(S, 2);
    ad = obj.action_dim;
    log2pi = log(2*pi);

    policy_losses = []; value_losses = []; entropies = [];

    for epoch = 1:obj.update_epochs
        perm = randperm(n);
        for s = 1:obj.batch_size:n
            mb = perm(s:min(s+obj.batch_size-1, n));
            mb_n = numel(mb);

            % ---- 策略前向 ----
            out = obj.policy.forward(S(:, mb));
            mean_v = out(1:ad, :);
            log_std = min(max(out(ad+1:end, :), -10), 1);
            z = Zall(:, mb);

            inv_var = exp(-2*log_std);
            newLP = -0.5 * sum((z - mean_v).^2 .* inv_var ...
                + 2*log_std + log2pi, 1);                 % [1,mb_n]
            entropy = sum(log_std + 0.5*(log2pi + 1), 1); % [1,mb_n]

            ratio = exp(min(max(newLP.' - oldLP(mb), -10), 10));
            ratio = min(max(ratio, 0.1), 10);             % [mb_n,1]
            A = adv(mb);
            surr1 = ratio .* A;
            surr2 = min(max(ratio, 1-obj.clip_ratio), 1+obj.clip_ratio) .* A;
            policy_loss = -mean(min(surr1, surr2));

            % ---- 价值前向 ----
            vpred = obj.value_net.forward(S(:, mb));
            vpred = vpred(1, :).';                        % [mb_n,1]
            vclip = 1.0;
            vpred_clipped = oldV(mb) + min(max(vpred - oldV(mb), -vclip), vclip);
            mse1 = mean((vpred - rets(mb)).^2);
            mse2 = mean((vpred_clipped - rets(mb)).^2);
            value_loss = max(mse1, mse2);
            entropy_term = mean(entropy);

            policy_losses(end+1) = policy_loss; %#ok<AGROW>
            value_losses(end+1) = value_loss;  %#ok<AGROW>
            entropies(end+1) = entropy_term;   %#ok<AGROW>

            % ---- 策略输出梯度 ----
            dPol = zeros(2*ad, mb_n);
            for j = 1:mb_n
                if surr1(j) <= surr2(j)
                    coef = -(ratio(j)*A(j)) / mb_n;        % 未裁剪分支
                else
                    coef = 0;                              % 裁剪分支无梯度
                end
                dz = z(:, j) - mean_v(:, j);
                iv = inv_var(:, j);
                dPol(1:ad, j) = coef .* (dz .* iv);
                dPol(ad+1:end, j) = coef .* (dz.^2 .* iv - 1) ...
                    - obj.entropy_coef / mb_n;
            end
            obj.policy.zero_grad();
            obj.policy.backward(dPol);
            clip_grad_norm(obj.policy, 0.5);
            obj.policy.adam_step(obj.lr);

            % ---- 价值输出梯度 ----
            dVal = zeros(1, mb_n);
            if mse1 >= mse2
                dVal = (2/mb_n) * (vpred - rets(mb)).';
            else
                for j = 1:mb_n
                    diff = vpred(j) - oldV(mb(j));
                    if abs(diff) <= vclip
                        dVal(j) = (2/mb_n) * (vpred_clipped(j) - rets(mb(j)));
                    end
                end
            end
            dVal = obj.value_coef * dVal;
            obj.value_net.zero_grad();
            obj.value_net.backward(dVal);
            clip_grad_norm(obj.value_net, 0.5);
            obj.value_net.adam_step(obj.lr);
        end
    end

    info.policy_loss = mean(policy_losses);
    info.value_loss = mean(value_losses);
    info.entropy = mean(entropies);
end

function clip_grad_norm(net, max_norm)
    % 对应 PyTorch 的 nn.utils.clip_grad_norm_
    total = 0;
    for l = 1:numel(net.dW)
        total = total + sum(net.dW{l}.^2, 'all') + sum(net.db{l}.^2, 'all');
    end
    total = sqrt(total);
    if total > max_norm
        scale = max_norm / total;
        for l = 1:numel(net.dW)
            net.dW{l} = net.dW{l} * scale;
            net.db{l} = net.db{l} * scale;
        end
    end
end
