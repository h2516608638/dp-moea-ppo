function hv = hv_monte_carlo(points, n_samples, seed)
    % 蒙特卡洛超体积(Hypervolume)估计
    %   points: 已归一化点 [n,M]，参考点为全 1；下界取各维最小
    %   n_samples: 蒙特卡洛样本数（默认 100000）；seed: 固定种子（默认 42）
    if nargin < 2, n_samples = 100000; end
    if nargin < 3, seed = 42; end
    if isempty(points)
        hv = 0;
        return
    end
    stream = RandStream('mt19937ar', 'Seed', seed);
    M = size(points, 2);
    lower = min(points, [], 1);
    span = 1 - lower;
    box_volume = prod(span);

    batch = 20000;
    hits = 0; done = 0;
    while done < n_samples
        size_b = min(batch, n_samples - done);
        loc = zeros(size_b, M);
        for j = 1:M
            loc(:, j) = lower(j) + span(j) * rand(stream, size_b, 1);
        end
        covered = false(size_b, 1);
        for p = 1:size(points, 1)
            dom = all(points(p, :) <= loc, 2);
            covered = covered | dom;
        end
        hits = hits + sum(covered);
        done = done + size_b;
    end
    hv = box_volume * (hits / n_samples);
end
