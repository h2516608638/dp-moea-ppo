classdef MLP < handle
    % MLP  通用多层全连接网络（手写前向/反向传播 + Adam）
    %   隐藏层激活 ReLU，输出层线性。
    %   输入/输出矩阵约定：列方向为 batch，即 X 大小为 [n_features, n_batch]。
    properties
        sizes          % 各层维度数组，例如 [8,256,256,6]
        W              % 各层权重 cell，W{l} 大小 [out,in]
        b              % 各层偏置 cell，b{l} 大小 [out,1]
        dW             % 权重梯度累积
        db             % 偏置梯度累积
        mW, vW, mb, vb % Adam 一阶/二阶矩
        t = 0          % Adam 时间步
        lr = 3e-4
        cacheA         % 前向激活缓存（含输入）
        cacheZ         % 前向线性输出缓存
    end

    methods
        function obj = MLP(sizes, gain)
            % sizes: 层维度数组；gain: 正交初始化增益（标量或与层数等长数组）
            obj.sizes = sizes;
            nL = numel(sizes) - 1;
            obj.W = cell(1, nL); obj.b = cell(1, nL);
            obj.dW = cell(1, nL); obj.db = cell(1, nL);
            obj.mW = cell(1, nL); obj.vW = cell(1, nL);
            obj.mb = cell(1, nL); obj.vb = cell(1, nL);
            if isscalar(gain), gain = repmat(gain, 1, nL); end
            for l = 1:nL
                obj.W{l} = ortho_init(sizes(l+1), sizes(l), gain(l));
                obj.b{l} = zeros(sizes(l+1), 1);
                obj.dW{l} = zeros(size(obj.W{l}));
                obj.db{l} = zeros(size(obj.b{l}));
                obj.mW{l} = zeros(size(obj.W{l}));
                obj.vW{l} = zeros(size(obj.W{l}));
                obj.mb{l} = zeros(size(obj.b{l}));
                obj.vb{l} = zeros(size(obj.b{l}));
            end
        end

        function zero_grad(obj)
            for l = 1:numel(obj.W)
                obj.dW{l}(:) = 0;
                obj.db{l}(:) = 0;
            end
        end

        function A = forward(obj, X)
            % 前向传播，返回输出并缓存中间量
            A = X;
            obj.cacheA = {A};
            obj.cacheZ = cell(1, numel(obj.W));
            for l = 1:numel(obj.W)
                Z = obj.W{l} * A + obj.b{l};
                obj.cacheZ{l} = Z;
                if l < numel(obj.W)
                    A = max(Z, 0);          % ReLU
                else
                    A = Z;                  % 输出层线性
                end
                obj.cacheA{l+1} = A;
            end
        end

        function backward(obj, dOut)
            % 反向传播，dOut 为损失对输出的梯度 [out,n_batch]，梯度在 dW/db 累积
            L = numel(obj.W);
            delta = dOut;
            for l = L:-1:1
                if l < L
                    delta = delta .* (obj.cacheZ{l} > 0);   % ReLU 导数
                end
                Aprev = obj.cacheA{l};
                obj.dW{l} = obj.dW{l} + delta * Aprev.';
                obj.db{l} = obj.db{l} + sum(delta, 2);
                delta = obj.W{l}.' * delta;                % 传播到上一层
            end
        end

        function adam_step(obj, lr)
            % 用累积梯度执行一次 Adam 更新
            if nargin >= 2, obj.lr = lr; end
            beta1 = 0.9; beta2 = 0.999; eps = 1e-5;
            obj.t = obj.t + 1;
            for l = 1:numel(obj.W)
                obj.mW{l} = beta1 * obj.mW{l} + (1-beta1) * obj.dW{l};
                obj.vW{l} = beta2 * obj.vW{l} + (1-beta2) * obj.dW{l}.^2;
                mhat = obj.mW{l} / (1-beta1^obj.t);
                vhat = obj.vW{l} / (1-beta2^obj.t);
                obj.W{l} = obj.W{l} - obj.lr * mhat ./ (sqrt(vhat) + eps);

                obj.mb{l} = beta1 * obj.mb{l} + (1-beta1) * obj.db{l};
                obj.vb{l} = beta2 * obj.vb{l} + (1-beta2) * obj.db{l}.^2;
                mhatb = obj.mb{l} / (1-beta1^obj.t);
                vhatb = obj.vb{l} / (1-beta2^obj.t);
                obj.b{l} = obj.b{l} - obj.lr * mhatb ./ (sqrt(vhatb) + eps);
            end
        end
    end
end

function Q = ortho_init(rows, cols, gain)
    % 正交初始化（对应 PyTorch 的 orthogonal initialization）
    if rows >= cols
        A = randn(rows, cols);
        [Q, ~] = qr(A, 0);
    else
        A = randn(cols, rows);
        [Q, ~] = qr(A, 0);
        Q = Q.';
    end
    Q = Q * gain;
end
