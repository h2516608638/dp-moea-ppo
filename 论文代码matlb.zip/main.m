%% DP-MOEA/PPO 独立 MATLAB 入口
%  使用方法：直接运行本文件（Run）。修改下方“配置区”切换问题与目标数。
clear; clc; close all;

%% ===================== 配置区 =====================
problem_name = 'dtlz2';   % 'dtlz1'..'dtlz7'
M            = 3;         % 目标数（2/3/5/8/10）
RUNS         = 5;         % 独立运行次数
% ==================================================

% 按目标数确定种群规模、邻域、代数与参考点数
switch M
    case {2,3}
        N = 100;  n_neighbors = 10; n_points = 1000;
    case 5
        N = 126;  n_neighbors = 20; n_points = 1820;
    case 8
        N = 156;  n_neighbors = 20; n_points = 2000;
    case 10
        N = 275;  n_neighbors = 25; n_points = 3000;
    otherwise
        error('支持的目标数为 2/3/5/8/10');
end
MAX_GEN = 500;

if ~exist('results', 'dir')
    mkdir('results');
end

final_igd = zeros(RUNS, 1);
all_igd_curves = cell(RUNS, 1);
last_best_P = [];

for r = 1:RUNS
    fprintf('\n========== 运行 %d/%d ==========\n', r, RUNS);
    set_seed(1000 + r);

    % 问题、权重、双种群
    problem = DTLZProblem(problem_name, M);
    W  = generate_weights(M, N);
    P1 = generate_population(problem, N);
    P2 = generate_population(problem, N);
    true_pf = problem.pareto_front(n_points);

    % 每次运行新建 PPO 智能体
    ppo = PPO(8, 3, [1,15,15], 3e-4, 0.99, 0.95, 0.2, 256, 32, 10);

    algo = MOEAD_PPO(problem, P1, P2, W, ppo, N, MAX_GEN, n_neighbors);
    [best_P, igd_curve, igd_t_min] = algo.run(true_pf);

    final_igd(r) = igd_t_min;
    all_igd_curves{r} = igd_curve(:);
    last_best_P = best_P;
    fprintf('运行 %d 最终 IGD = %.6f\n', r, igd_t_min);
end

%% 汇总
fprintf('\n================ 汇总 ================\n');
fprintf('问题: %s, M=%d, RUNS=%d\n', upper(problem_name), M, RUNS);
fprintf('IGD 均值 = %.6f, 标准差 = %.6f\n', mean(final_igd), std(final_igd));
fprintf('各次 IGD: %s\n', mat2str(final_igd, 6));

% 保存结果
tag = sprintf('%s_M%d', problem_name, M);
save(fullfile('results', ['IGD_', tag, '.mat']), 'final_igd', 'all_igd_curves', ...
    'problem_name', 'M', 'N', 'MAX_GEN', 'RUNS');
writematrix(final_igd, fullfile('results', ['IGD_', tag, '.csv']));

%% 可选：对最后一次运行的最优种群计算 HV（蒙特卡洛）
F_best = problem.evaluate(last_best_P);
normalization = 1.1 * max(F_best, [], 1);
F_norm = F_best ./ (normalization + 1e-10);
hv = hv_monte_carlo(F_norm, 100000, 42);
fprintf('HV（蒙特卡洛估计，归一化口径）= %.6f\n', hv);
