function F = evaluate(obj, X)
    % 评估决策变量，X 大小 [n,n_var]，返回 F [n,n_obj]
    if isvector(X)
        X = X(:).';
    end
    n = size(X, 1);
    M = obj.n_obj;
    F = zeros(n, M);
    for r = 1:n
        x = X(r, :);
        xp = x(1:M-1);
        xm = x(M:end);
        switch obj.name
            case 'dtlz1'
                g = 100 * (numel(xm) + sum((xm-0.5).^2 - cos(2*pi*(xm-0.5))));
                F(r, :) = dtlz_cos_form(xp, g, M, @(t) t, false);
            case 'dtlz2'
                g = sum((xm-0.5).^2);
                F(r, :) = dtlz_cos_form(xp, g, M, @(t) t, true);
            case 'dtlz3'
                g = 100 * (numel(xm) + sum((xm-0.5).^2 - cos(2*pi*(xm-0.5))));
                F(r, :) = dtlz_cos_form(xp, g, M, @(t) t, true);
            case 'dtlz4'
                g = sum((xm-0.5).^2);
                F(r, :) = dtlz_cos_form(xp.^100, g, M, @(t) t, true);
            case 'dtlz5'
                g = sum((xm-0.5).^2);
                theta = degenerate_theta(xp, g, M);
                F(r, :) = theta_form(theta, g, M);
            case 'dtlz6'
                g = sum(xm.^0.1);
                theta = degenerate_theta(xp, g, M);
                F(r, :) = theta_form(theta, g, M);
            case 'dtlz7'
                g = sum(xm.^0.1);
                y = xp;
                h = M - sum(y .* (1 + sin(3*pi*y))) / (1 + g);
                F(r, 1:M-1) = y;
                F(r, M) = (1 + g) * h;
        end
    end
end

function f = dtlz_cos_form(xp, g, M, ~, is_cos)
    % 通用 DTLZ 累乘形式
    f = zeros(1, M);
    if is_cos
        a = xp * pi/2;
    else
        a = xp;
    end
    for i = 0:M-1
        val = 0.5 * (1 + g);
        if is_cos
            val = 1 + g;
        end
        for j = 1:M-1-i
            if is_cos
                val = val * cos(a(j));
            else
                val = val * a(j);
            end
        end
        if i > 0
            if is_cos
                val = val * sin(a(M-i));
            else
                val = val * (1 - a(M-i));
            end
        end
        f(i+1) = val;
    end
end

function theta = degenerate_theta(xp, g, M)
    theta = zeros(1, M-1);
    theta(1) = xp(1) * pi/2;
    for j = 2:M-1
        theta(j) = pi/(4*(1+g)) * (1 + 2*g*xp(j));
    end
end

function f = theta_form(theta, g, M)
    f = zeros(1, M);
    for i = 0:M-1
        val = 1 + g;
        for j = 1:M-1-i
            val = val * cos(theta(j));
        end
        if i > 0
            val = val * sin(theta(M-i));
        end
        f(i+1) = val;
    end
end
