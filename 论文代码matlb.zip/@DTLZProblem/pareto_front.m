function PF = pareto_front(obj, n_points)
    % 生成解析 Pareto 前沿参考点，大小 [~,n_obj]
    if nargin < 2, n_points = 1000; end
    M = obj.n_obj;

    switch obj.name
        case 'dtlz1'
            P = pick_simplex(M, n_points);
            PF = P * 0.5;
        case {'dtlz2','dtlz3','dtlz4'}
            P = pick_simplex(M, n_points);
            norms = sqrt(sum(P.^2, 2));
            PF = P ./ norms;
        case {'dtlz5','dtlz6'}
            t = linspace(0, 1, n_points).';
            PF = zeros(n_points, M);
            for k = 1:n_points
                theta = zeros(1, max(M-1,1));
                theta(1) = t(k)*pi/2;
                if M >= 3
                    theta(2:M-1) = pi/4;
                end
                PF(k, :) = theta_form(theta, M);
            end
        case 'dtlz7'
            if M == 2
                t = linspace(0, 1, n_points).';
                PF = [t, 2 - t.*(1 + sin(3*pi*t))];
            else
                Y = pick_simplex(M-1, n_points);
                h = M - sum(Y .* (1 + sin(3*pi*Y)), 2);
                PF = [Y, h];
            end
    end
end

function P = pick_simplex(M, n_points)
    % 选择最小的划分 p，使 Das-Dennis 点数不少于 n_points
    p = 1;
    while nchoosek(p+M-1, M-1) < n_points
        p = p + 1;
    end
    P = simplex_points(M, p);
end

function P = simplex_points(M, p)
    % Das-Dennis 单纯形均匀点
    n = nchoosek(p+M-1, M-1);
    if M == 1
        P = ones(n,1);
        return
    end
    c = nchoosek(1:p+M-1, M-1);
    aug = [zeros(n,1), c, (p+M)*ones(n,1)];
    P = diff(aug, 1, 2) - 1;
    P = P / p;
end

function f = theta_form(theta, M)
    f = zeros(1, M);
    for i = 0:M-1
        val = 1;
        for j = 1:M-1-i
            val = val * cos(theta(j));
        end
        if i > 0
            val = val * sin(theta(M-i));
        end
        f(i+1) = val;
    end
end
