classdef DTLZProblem < handle
    % DTLZProblem  DTLZ1-7 标准测试问题（最小化，决策变量范围 [0,1]）
    properties
        name
        n_var
        n_obj
        xl          % 行向量
        xu          % 行向量
    end

    methods
        function obj = DTLZProblem(name, n_obj, n_var)
            % name: 'dtlz1'..'dtlz7'；n_var 省略时按标准 k 自动确定
            obj.name = lower(name);
            obj.n_obj = n_obj;
            if nargin < 3 || isempty(n_var)
                switch obj.name
                    case 'dtlz1'
                        k = 5;
                    case 'dtlz7'
                        k = 20;
                    otherwise
                        k = 10;
                end
                n_var = n_obj + k - 1;
            end
            obj.n_var = n_var;
            obj.xl = zeros(1, n_var);
            obj.xu = ones(1, n_var);
        end
    end
end
