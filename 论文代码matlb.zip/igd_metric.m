function val = igd_metric(F, PF)
    % IGD (Inverted Generational Distance)：参考点到解集的平均最小距离
    if isempty(PF) || isempty(F)
        val = 0;
        return
    end
    D = pairwise_dist(PF, F);   % [n_ref,n_sol]
    val = mean(min(D, [], 2));
end
