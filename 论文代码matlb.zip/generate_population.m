function P = generate_population(problem, n_pop)
    % 在 [xl,xu] 内均匀随机生成初始种群 [n_pop,n_var]
    D = problem.n_var;
    P = zeros(n_pop, D);
    for j = 1:D
        P(:, j) = problem.xl(j) + (problem.xu(j)-problem.xl(j)) * rand(n_pop, 1);
    end
end
