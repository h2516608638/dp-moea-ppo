function [W_new, del_idx, add_weights] = adapt_weights(W, F, n_clusters, ...
        n_replace, angle_th_del, angle_th_add, seed) %#ok<INUSD>
    % 基于聚类的权重自适应
    %   删除规则 crowded_performance：先删覆盖度低/靠近簇心的，再从最大簇补删
    %   添加规则 dirichlet_sparse_pf：围绕 F 稀疏方向中心做 Dirichlet 采样
    % 依赖 Statistics and Machine Learning Toolbox 的 drnd
    W = normalize_weights(W);
    [N, M] = size(W);

    % ---- 启发式确定簇数 k ----
    k = min(n_clusters, max(1, floor(sqrt(max(1,N)))));
    k = min(k, max(1, floor(N/5)));
    k = min(k, 10);
    k = max(k, 1);

    [centers, assign, clusters] = kmeans_simple(W, k, 50);
    sizes = cellfun(@numel, clusters);

    % ---- F 方向与覆盖统计 ----
    if nargin >= 2 && ~isempty(F)
        F_dir = normalize_F(F);
    else
        F_dir = [];
    end
    cover_count = assign_F_angles(F_dir, W, N);

    % ==================== 删除：crowded_performance ====================
    del_idx = [];
    [~, order_cov] = sort(cover_count, 'ascend');     % 覆盖度小 -> 大
    for ii = 1:numel(order_cov)
        if numel(del_idx) >= n_replace, break; end
        idx = order_cov(ii);
        cid = assign(idx);
        ang = cos_ang(W(idx,:), centers(cid,:));
        if cover_count(idx) == 0 || ang <= angle_th_del*1.25
            del_idx(end+1) = idx; %#ok<AGROW>
        end
    end

    if numel(del_idx) < n_replace                     % 从最大簇补删
        [~, order] = sort(sizes, 'descend');
        for ci = 1:numel(order)
            if numel(del_idx) >= n_replace, break; end
            cid = order(ci);
            cidxs = clusters{cid};
            cidxs = cidxs(~ismember(cidxs, del_idx));
            if isempty(cidxs), continue; end
            angs = arrayfun(@(i) cos_ang(W(i,:), centers(cid,:)), cidxs);
            [~, po] = sort(angs, 'ascend');
            for pi = 1:numel(po)
                if numel(del_idx) >= n_replace, break; end
                i = cidxs(po(pi));
                if angs(po(pi)) <= angle_th_del || cover_count(i) <= median(cover_count)
                    del_idx(end+1) = i; %#ok<AGROW>
                end
            end
        end
    end

    del_idx = unique(del_idx);
    if isempty(del_idx)
        W_new = W;
        add_weights = zeros(0, M);
        return
    end

    % ==================== 添加：dirichlet_sparse_pf ====================
    keep_mask = true(N,1);
    keep_mask(del_idx) = false;
    W_keep = W(keep_mask, :);
    n_add = numel(del_idx);
    add_weights = [];
    add_needed = n_add;

    if ~isempty(F_dir)
        [f_centers, ~, f_clusters] = kmeans_simple(F_dir, k, 30);
        f_sizes = cellfun(@numel, f_clusters);
        [~, f_order] = sort(f_sizes, 'ascend');      % 稀疏方向优先
        for ci = 1:numel(f_order)
            if add_needed <= 0, break; end
            cid = f_order(ci);
            cs = max(abs(f_centers(cid,:)), 1e-12);
            cs = cs / (sum(cs) + 1e-12);
            samples = sample_dirichlet(cs, 25.0, add_needed*4);
            [~, add_weights, add_needed] = filter_samples(samples, ...
                W_keep, add_weights, add_needed, angle_th_add);
        end
    end

    if add_needed > 0                                % 退化为簇中心采样
        [~, corder] = sort(sizes, 'ascend');
        for ci = 1:numel(corder)
            if add_needed <= 0, break; end
            cid = corder(ci);
            samples = sample_dirichlet(centers(cid,:), 20.0, add_needed*3);
            [~, add_weights, add_needed] = filter_samples(samples, ...
                W_keep, add_weights, add_needed, angle_th_add);
        end
    end

    if add_needed > 0                                % 兜底：全局 Dirichlet
        extra = drnd(ones(1,M), add_needed);
        [~, add_weights, add_needed] = filter_samples(extra, ...
            W_keep, add_weights, add_needed, angle_th_add);
        if add_needed > 0
            extra_any = drnd(ones(1,M), add_needed);
            add_weights = [add_weights; extra_any];
        end
    end

    % ==================== 组装 ====================
    W_keep = W(keep_mask, :);
    W_new = normalize_weights([W_keep; add_weights]);
    if size(W_new,1) ~= N || size(W_new,2) ~= M || ~all(isfinite(W_new),'all')
        W_new = W;
        del_idx = [];
        add_weights = zeros(0, M);
    end
end

% ---------------- 辅助函数 ----------------
function W = normalize_weights(W)
    W = max(W, 1e-12);
    W = W ./ (sum(W,2) + 1e-12);
end

function D = normalize_F(F)
    fmin = min(F, [], 1);
    D = F - fmin;
    D = D ./ (sqrt(sum(D.^2,2)) + 1e-12);
end

function cover = assign_F_angles(F_dir, W, N)
    if isempty(F_dir)
        cover = zeros(N,1);
        return
    end
    nf = size(F_dir,1);
    A = zeros(nf, size(W,1));
    for i = 1:nf
        for j = 1:size(W,1)
            A(i,j) = cos_ang(F_dir(i,:), W(j,:));
        end
    end
    [~, nearest] = min(A, [], 2);
    cover = accumarray(nearest, 1, [N,1]);
end

function samples = sample_dirichlet(center, alpha_scale, n_samples)
    alpha = 1.0 + alpha_scale * max(center, 1e-12);
    samples = drnd(alpha, n_samples);
end

function [picked, add_weights, add_needed] = filter_samples(samples, W_keep, ...
        add_weights, add_needed, angle_th_add)
    picked = [];
    for s = 1:size(samples,1)
        w = samples(s,:);
        if min_angle(w, W_keep) >= angle_th_add && min_angle(w, add_weights) >= angle_th_add
            picked(end+1, :) = w; %#ok<AGROW>
            add_weights(end+1, :) = w; %#ok<AGROW>
            add_needed = add_needed - 1;
        end
        if add_needed <= 0, break; end
    end
end

function ma = min_angle(w, Wset)
    if isempty(Wset)
        ma = inf;
        return
    end
    ma = inf;
    for i = 1:size(Wset,1)
        ma = min(ma, cos_ang(w, Wset(i,:)));
    end
end

function a = cos_ang(u, v)
    nu = norm(u) + 1e-12;
    nv = norm(v) + 1e-12;
    c = dot(u,v)/(nu*nv);
    c = min(max(c,-1),1);
    a = acos(c);
end
