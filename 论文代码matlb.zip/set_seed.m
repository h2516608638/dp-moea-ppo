function set_seed(seed)
    % 固定随机数种子，保证可复现（同时设置默认全局流）
    rng(seed, 'twister');
end
