function ang = cosine_angle(v1, v2)
    % 两个向量的夹角（弧度），基于余弦相似度
    n1 = norm(v1);
    n2 = norm(v2);
    if n1 < 1e-12 || n2 < 1e-12
        ang = 0;
        return
    end
    c = dot(v1, v2) / (n1*n2);
    c = min(max(c, -1), 1);
    ang = acos(c);
end
