function theta = get_angle(obj, gen)
    % 动态角度阈值，随进化进度在初始/最终值间线性插值
    progress = gen / obj.max_gen;
    theta = obj.theta_initial + (obj.theta_final - obj.theta_initial) * progress;
end
