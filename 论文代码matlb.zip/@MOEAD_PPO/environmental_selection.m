function [P_new, srr] = environmental_selection(obj, P, offspring, epsilon)
    % 合并父代与子代 -> 非支配排序 -> 按层与拥挤距离选择 n_pop 个
    if iscell(offspring)
        offspring = cell2mat(offspring(:));
    end
    P_combined = [P; offspring];
    nP = size(P, 1);
    nO = size(offspring, 1);
    is_offspring = [false(nP,1); true(nO,1)];

    F_combined = obj.problem.evaluate(P_combined);
    if obj.n_obj > 3
        fronts = epsilon_nds(obj, F_combined, epsilon);
    else
        fronts = fast_nds(obj, F_combined);
    end

    sel = [];
    remaining = obj.n_pop;
    for fi = 1:numel(fronts)
        if remaining <= 0
            break
        end
        fr = fronts{fi};
        if numel(fr) <= remaining
            sel = [sel, fr]; %#ok<AGROW>
            remaining = remaining - numel(fr);
        else
            F_front = F_combined(fr, :);
            cd = crowding_distance(obj, F_front);
            [~, ord] = sort(cd, 'descend');
            sel = [sel, fr(ord(1:remaining))];
            remaining = 0;
        end
    end

    P_new = P_combined(sel, :);
    srr = sum(is_offspring(sel));
end
