function val = igd(~, F, PF)
    % IGD（Inverted Generational Distance）
    val = igd_metric(F, PF);
end
