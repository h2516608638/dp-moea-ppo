function reward = calculate_reward(obj, igd1, prev_igd1, crowd1, prev_crowd1, ...
        igd2, prev_igd2, crowd2, prev_crowd2, nd_count, prev_nd_count, recent_SRR_mean) %#ok<INUSD>
    % 层级式奖励：收敛主奖励 + 多样性约束 + 非支配增量
    if isempty(prev_igd1) || isempty(prev_crowd1) || isempty(prev_igd2) ...
            || isempty(prev_crowd2) || isempty(prev_nd_count)
        reward = 0;
        return
    end

    igd_cur = (igd1 + igd2) / 2;
    igd_prev = (prev_igd1 + prev_igd2) / 2;
    if igd_prev < 1e-8
        rel_imp = 0;
    else
        rel_imp = (igd_prev - igd_cur) / igd_prev;
    end
    r_main = tanh(2 * rel_imp);

    crowd_cur = (crowd1 + crowd2) / 2;
    crowd_prev = (prev_crowd1 + prev_crowd2) / 2;
    if crowd_prev < 1e-8
        crowd_change = 0;
    else
        crowd_change = (crowd_cur - crowd_prev) / crowd_prev;
    end
    r_div = min(max(-0.5 * crowd_change, -0.3), 0.1);

    if prev_nd_count < 1
        r_nd = 0;
    else
        nd_change = (nd_count - prev_nd_count) / prev_nd_count;
        r_nd = 0.1 * min(max(nd_change, -1), 1);
    end

    reward = min(max(r_main + r_div + r_nd, -1.2), 1.2);
end
