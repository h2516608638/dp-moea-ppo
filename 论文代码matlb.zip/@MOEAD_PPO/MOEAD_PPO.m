classdef MOEAD_PPO < handle
    % MOEAD_PPO  DP-MOEA/PPO 主算法：双异质种群 + PPO 单控制器 + 权重自适应
    properties
        problem
        n_var
        n_obj
        n_pop
        n_neighbors
        max_gen
        xl
        xu
        H
        W                   % 权重矩阵（WS 变换后）
        P1                  % 种群1：基于分解
        P2                  % 种群2：基于角度支配
        theta_initial
        theta_final
        SRR = 0
        SRR_history = []
        best_P
        rho = 1e-4
        Z                   % 理想点
        B                   % 邻域索引
        state_dim = 8
        action_dim = 3
        action_bound
        action_offset
        ppo
        % 状态跟踪
        prev_igd1 = []
        prev_reward = 0
        prev_Z
        prev_crowd1 = []
        prev_state = []
        prev_action = []
        prev_value = []
        prev_log_prob = []
        episode_step = 0
        update_frequency = 20
        % Log1p 归一化基准
        igd_init_p1 = []
        igd_init_p2 = []
        igd_init_count = 0
        igd_init_sum_p1 = 0
        igd_init_sum_p2 = 0
        % 替换计数/尝试
        replace_count1 = 0
        replace_count2 = 0
        replace_attempt1 = 0
        replace_attempt2 = 0
        epm
    end

    methods
        function obj = MOEAD_PPO(problem, P1, P2, W, ppo, n_pop, max_gen, n_neighbors)
            if nargin < 8, n_neighbors = 10; end
            obj.problem = problem;
            obj.n_var = problem.n_var;
            obj.n_obj = problem.n_obj;
            obj.n_pop = n_pop;
            obj.n_neighbors = n_neighbors;
            obj.max_gen = max_gen;
            obj.xu = problem.xu;
            obj.xl = problem.xl;
            obj.H = n_pop - 1;

            obj.W = W;
            obj.W = ws_transform(obj);
            obj.P1 = P1;
            obj.P2 = P2;

            obj.theta_initial = deg2rad(30);
            obj.theta_final = deg2rad(60);
            obj.best_P = P1;
            obj.rho = 1e-4;

            F1 = problem.evaluate(P1);
            F2 = problem.evaluate(P2);
            obj.Z = min([min(F1,[],1); min(F2,[],1)], [], 1);

            obj.B = get_neighbors(obj);

            obj.action_bound = [1, 15, 15];
            obj.action_offset = [0, 2, 5];
            obj.ppo = ppo;

            obj.prev_Z = obj.Z;
            obj.epm = EP_Maintainer(n_pop);
        end
    end
end
