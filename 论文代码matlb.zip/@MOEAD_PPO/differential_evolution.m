function x_new = differential_evolution(obj, x1, x2, x3, F)
    % 差分进化（Differential Evolution）算子
    beta = abs(x2 - x3);
    x_new = x1 + F * beta;
    x_new = min(max(x_new, obj.xl), obj.xu);
end
