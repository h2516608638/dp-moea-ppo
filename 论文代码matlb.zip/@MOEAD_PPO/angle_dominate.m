function ang = angle_dominate(obj, f1, f2)
    % 相对理想点的两目标向量夹角；点积为负返回 -1（对应 Python 的 False）
    v1 = f1 - obj.Z;
    v2 = f2 - obj.Z;
    dp = dot(v1, v2);
    if dp < 0
        ang = -1;
        return
    end
    n1 = norm(v1);
    n2 = norm(v2);
    c = dp / (n1*n2);
    c = min(max(c, -1), 1);
    ang = acos(c);
end
