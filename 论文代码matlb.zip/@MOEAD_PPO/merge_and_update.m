function merge_and_update(obj)
    % 合并双种群 -> 非支配排序选择 n_pop -> 更新 P1、理想点、权重
    combined = [obj.P1; obj.P2];
    Fc = obj.problem.evaluate(combined);
    fronts = fast_nds(obj, Fc);

    sel = [];
    for fi = 1:numel(fronts)
        fr = fronts{fi};
        if numel(sel) + numel(fr) <= obj.n_pop
            sel = [sel, fr]; %#ok<AGROW>
        else
            remaining = obj.n_pop - numel(sel);
            cd = crowding_distance(obj, Fc(fr,:));
            [~, ord] = sort(cd, 'descend');
            sel = [sel, fr(ord(1:remaining))];
            break
        end
    end

    obj.P1 = combined(sel, :);
    Fn = obj.problem.evaluate(obj.P1);
    obj.Z = min(obj.Z, min(Fn, [], 1));
    aw2(obj);
end
