function child = crossover_sbx(obj, a, b, eta)
    % SBX (Simulated Binary Crossover)，逐维采样
    u = rand(1, numel(a));
    beta = zeros(size(u));
    left = u <= 0.5;
    beta(left) = (2*u(left)).^(1/(eta+1));
    beta(~left) = (1 ./ (2*(1-u(~left)) + 1e-10)).^(1/(eta+1));
    diff = abs(a - b);
    child1 = 0.5*(a + b - beta.*diff);
    child2 = 0.5*(a + b + beta.*diff);
    if rand < 0.5
        child = child1;
    else
        child = child2;
    end
    child = min(max(child, obj.xl), obj.xu);
end
