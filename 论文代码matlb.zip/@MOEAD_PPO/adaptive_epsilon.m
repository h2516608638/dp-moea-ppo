function epsilon = adaptive_epsilon(obj, gen, base_epsilon)
    % 自适应 epsilon：高维更小，随进化进度衰减，下限 0.01
    if nargin < 3, base_epsilon = 0.05; end
    progress = gen / obj.max_gen;
    if obj.n_obj >= 5
        epsilon = base_epsilon * (1 / log(obj.n_obj + 1));
    else
        epsilon = base_epsilon;
    end
    epsilon = epsilon * (1 - progress*0.8);
    epsilon = max(epsilon, 0.01);
end
