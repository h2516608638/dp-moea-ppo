function crowding = crowding_distance(~, F)
    % NSGA-II 拥挤距离
    [n, m] = size(F);
    crowding = zeros(n, 1);
    if n <= 2
        crowding = inf(n, 1);
        return
    end
    for o = 1:m
        [~, si] = sort(F(:, o));
        crowding(si(1)) = inf;
        crowding(si(end)) = inf;
        fmin = F(si(1), o);
        fmax = F(si(end), o);
        if fmax - fmin < 1e-10
            continue
        end
        scale = fmax - fmin;
        for i = 2:n-1
            diff = F(si(i+1), o) - F(si(i-1), o);
            crowding(si(i)) = crowding(si(i)) + diff / scale;
        end
    end
end
