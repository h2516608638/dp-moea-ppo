function fronts = fast_nds(~, F)
    % 快速非支配排序（Fast Non-dominated Sorting），返回 fronts cell
    n = size(F, 1);
    if n == 0
        fronts = {};
        return
    end
    S = cell(n,1);
    np = zeros(n,1);
    for p = 1:n
        S{p} = [];
        for q = 1:n
            if p == q
                continue
            end
            if all(F(p,:) <= F(q,:)) && any(F(p,:) < F(q,:))
                S{p}(end+1) = q;
            elseif all(F(q,:) <= F(p,:)) && any(F(q,:) < F(p,:))
                np(p) = np(p) + 1;
            end
        end
    end

    fronts = {find(np == 0).'};
    i = 1;
    while i <= numel(fronts)
        nxt = [];
        for p = fronts{i}
            for q = S{p}
                np(q) = np(q) - 1;
                if np(q) == 0
                    nxt(end+1) = q; %#ok<AGROW>
                end
            end
        end
        if isempty(nxt)
            break
        end
        fronts{end+1} = nxt; %#ok<AGROW>
        i = i + 1;
    end
end
