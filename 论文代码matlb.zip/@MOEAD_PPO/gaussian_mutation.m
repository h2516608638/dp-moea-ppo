function x = gaussian_mutation(obj, x, sigma, mutation)
    % 高斯变异，逐维使用该维真实边界
    if nargin < 3, sigma = []; end
    if nargin < 4, mutation = 1/numel(x); end
    for i = 1:numel(x)
        if rand < mutation
            lb = obj.xl(i);
            ub = obj.xu(i);
            if isempty(sigma)
                sig = (ub-lb)*0.15;
            else
                sig = sigma;
            end
            x(i) = min(max(x(i) + sig*randn, lb), ub);
        end
    end
end
