function [state, igd1, crowd1, crowd2, igd2] = get_state(obj, gen, true_pf, epsilon) %#ok<INUSD>
    % 8 维状态：[progress, igd1_norm, igd2_norm, srr1, srr2, crowd1, crowd2, nd_ratio]
    progress = gen / obj.max_gen;

    F1 = obj.problem.evaluate(obj.P1);
    F2 = obj.problem.evaluate(obj.P2);
    if ~isempty(true_pf)
        igd1 = obj.igd(F1, true_pf);
        igd2 = obj.igd(F2, true_pf);
    else
        igd1 = 0; igd2 = 0;
    end

    if isempty(obj.igd_init_p1)
        obj.igd_init_sum_p1 = obj.igd_init_sum_p1 + igd1;
        obj.igd_init_sum_p2 = obj.igd_init_sum_p2 + igd2;
        obj.igd_init_count = obj.igd_init_count + 1;
        if obj.igd_init_count >= 5
            obj.igd_init_p1 = obj.igd_init_sum_p1 / 5;
            obj.igd_init_p2 = obj.igd_init_sum_p2 / 5;
        end
        igd1_norm = 0; igd2_norm = 0;
    else
        igd1_norm = 1 - log1p(igd1) / log1p(obj.igd_init_p1 + 1e-8);
        igd2_norm = 1 - log1p(igd2) / log1p(obj.igd_init_p2 + 1e-8);
        igd1_norm = min(max(igd1_norm, 0), 1.2);
        igd2_norm = min(max(igd2_norm, 0), 1.2);
    end

    srr1 = min(1, obj.replace_count1 / max(obj.replace_attempt1, 1e-8));
    srr2 = min(1, obj.replace_count2 / max(obj.replace_attempt2, 1e-8));

    cr1 = calculate_F(obj, F1);
    if ~isempty(cr1), crowd1 = mean(cr1); else crowd1 = 0; end
    if isnan(crowd1) || isinf(crowd1), crowd1 = 0; end
    cr2 = calculate_F(obj, F2);
    if ~isempty(cr2), crowd2 = mean(cr2); else crowd2 = 0; end
    if isnan(crowd2) || isinf(crowd2), crowd2 = 0; end

    nd_ratio = min(1, numel(obj.epm.ep) / max(obj.n_pop, 1));

    state = [progress, igd1_norm, igd2_norm, srr1, srr2, crowd1, crowd2, nd_ratio];
    state(isnan(state)) = 0;
    state(state == inf) = 1;
    state(state == -inf) = 0;
end
