function x = mutation_poly(obj, x, eta_m)
    % 多项式变异（Polynomial Mutation），变异概率 1/D
    pm = 1 / obj.n_var;
    for i = 1:obj.n_var
        if rand <= pm
            range_iu = obj.xu(i) - obj.xl(i);
            r = rand;
            if r <= 0.5
                term = 2*r + (1-2*r) * ((obj.xu(i)-x(i))/range_iu)^(eta_m+1);
                delta = term^(1/(eta_m+1)) - 1;
            else
                term = 2-2*r + (2*r-1) * ((x(i)-obj.xl(i))/range_iu)^(eta_m+1);
                delta = 1 - term^(1/(eta_m+1));
            end
            x(i) = x(i) + delta*range_iu;
            x(i) = min(max(x(i), obj.xl(i)), obj.xu(i));
        end
    end
end
