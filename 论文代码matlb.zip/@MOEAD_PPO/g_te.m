function tf = g_te(obj, x_old, x_new, index)
    % Tchebycheff 分解（含 rho 求和项），g_new < g_old 时返回 true
    f_old = obj.problem.evaluate(x_old);
    f_new = obj.problem.evaluate(x_new);
    if size(f_old,1) > 1, f_old = f_old(1,:); end
    if size(f_new,1) > 1, f_new = f_new(1,:); end
    w = obj.W(index, :);
    do = abs(f_old - obj.Z);
    dn = abs(f_new - obj.Z);
    g_old = max(w .* do) + obj.rho * sum(w .* do);
    g_new = max(w .* dn) + obj.rho * sum(w .* dn);
    tf = g_new < g_old;
end
