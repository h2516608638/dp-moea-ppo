function aw2(obj)
    % 基于 best_P 目标值与理想点的差值比例更新权重
    if isempty(obj.best_P)
        return
    end
    F = obj.problem.evaluate(obj.best_P);
    nw = zeros(size(F));
    for i = 1:size(F,1)
        denom = sum(F(i,:) - obj.Z);
        if denom == 0
            nw(i,:) = ones(1, obj.n_obj) / obj.n_obj;
        else
            nw(i,:) = (F(i,:) - obj.Z) / denom;
        end
    end
    obj.W = nw;
end
