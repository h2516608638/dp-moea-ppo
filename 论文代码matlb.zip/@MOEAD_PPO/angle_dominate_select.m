function tf = angle_dominate_select(obj, x_old, x_new, current_theta, index, epsilon)
    % 角度小用 epsilon-Pareto 支配，角度大用 Tchebycheff 分解
    f_old = obj.problem.evaluate(x_old);
    f_new = obj.problem.evaluate(x_new);
    if size(f_old,1) > 1, f_old = f_old(1,:); end
    if size(f_new,1) > 1, f_new = f_new(1,:); end
    ang = angle_dominate(obj, f_old, f_new);
    if ang <= current_theta
        all_ok = all(f_new <= (1+epsilon)*f_old);
        one_ok = any(f_new < (1+epsilon)*f_old);
        tf = all_ok && one_ok;
    else
        tf = g_te(obj, x_old, x_new, index);
    end
end
