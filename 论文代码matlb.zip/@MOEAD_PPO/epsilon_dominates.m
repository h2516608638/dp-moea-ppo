function tf = epsilon_dominates(~, a, b, epsilon)
    % a 是否 epsilon-支配 b（最小化）
    thr = (1+epsilon) * b;
    tf = all(a <= thr) && any(a < thr);
end
