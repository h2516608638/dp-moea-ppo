function B = get_neighbors(obj)
    % 权重欧氏距离，返回每个权重最近的 n_neighbors 个邻居索引
    D = pairwise_dist(obj.W, obj.W);
    [~, ord] = sort(D, 2);
    B = ord(:, 1:obj.n_neighbors);
end
