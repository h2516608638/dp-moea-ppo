function [best_P, igd_values, igd_t_min] = run(obj, true_pf)
    % DP-MOEA/PPO 主运行函数
    igd_values = [];
    igd_window = [];
    igd_t_min = inf;
    prev_igd1 = []; prev_igd2 = [];
    prev_crowd1 = []; prev_crowd2 = [];
    prev_nd = [];
    recent_SRR_mean = 0;
    action_phase = 0; F_de = 0.8; eta = 2; eta_m = 10;

    fprintf('种群大小: %d, 权重大小: %d\n', size(obj.P1,1), size(obj.W,1));

    for gen = 0:obj.max_gen-1
        child1 = {}; child2 = {};
        epsilon = adaptive_epsilon(obj, gen);

        F1_prev = obj.problem.evaluate(obj.P1);
        try
            obj.epm.update(rows_to_cell(F1_prev));
        catch
        end

        [state, igd1, crowd1, crowd2, igd2] = get_state(obj, gen, true_pf, epsilon);
        [action, value, log_prob] = obj.ppo.select_action(state, gen < 100);

        if gen >= 100
            action_phase = action(1);
            eta = obj.action_offset(2) + action(2);
            eta_m = obj.action_offset(3) + action(3);
        end
        eta = fix_nan(eta, 5);
        eta_m = fix_nan(eta_m, 10);
        eta = min(max(eta, 1.5), 17);
        eta_m = min(max(eta_m, 5), 25);

        srr1 = 0; srr2 = 0; attempt1 = 0; attempt2 = 0;
        current_theta = get_angle(obj, gen);
        alpha = gen / obj.max_gen;
        F_de = 0.5 + 0.3/(1 + exp(8*(alpha - 0.5)));

        phase_condition = action_phase > 0.4 && gen >= obj.max_gen*0.2;

        if obj.n_obj <= 3
            if gen < obj.max_gen*0.4
                cp = 0.8;
            elseif gen > obj.max_gen*0.6
                cp = 0.7;
            else
                cp = 0.6;
            end
        else
            if gen < obj.max_gen*0.2
                cp = 0.7;
            elseif gen > obj.max_gen*0.8
                cp = 0.6;
            else
                cp = 0.5;
            end
        end

        if ~phase_condition
            % ================= 阶段1：基于分解的协同进化 =================
            for i = 1:obj.n_pop
                % ---------- 种群1 ----------
                if rand < cp
                    neighbors = obj.B(i,:);
                    pidx = sample_n(neighbors, 2);
                    child = crossover_sbx(obj, obj.P1(pidx(1),:), obj.P1(pidx(2),:), eta);
                    child = mutation_poly(obj, child, eta_m);
                    f = obj.problem.evaluate(child);
                    obj.Z = min(obj.Z, f);
                    attempt1 = attempt1 + numel(neighbors);
                    for j = neighbors
                        if g_te(obj, obj.P1(j,:), child, j)
                            obj.P1(j,:) = child;
                            srr1 = srr1 + 1;
                        end
                    end
                else
                    pidx = sample_n(1:obj.n_pop, 2);
                    child = crossover_sbx(obj, obj.P2(pidx(1),:), obj.P2(pidx(2),:), eta);
                    child = mutation_poly(obj, child, eta_m);
                    f = obj.problem.evaluate(child);
                    obj.Z = min(obj.Z, f);
                    attempt1 = attempt1 + obj.n_pop;
                    for j = 1:obj.n_pop
                        if g_te(obj, obj.P1(j,:), child, j)
                            obj.P1(j,:) = child;
                            srr1 = srr1 + 1;
                        end
                    end
                end

                % ---------- 种群2 ----------
                if rand < 0.9
                    neighbors = obj.B(i,:);
                    if numel(neighbors) > 3
                        pidx = sample_n(neighbors, 3);
                        a = obj.P2(pidx(1),:); b = obj.P2(pidx(2),:); c = obj.P2(pidx(3),:);
                    elseif numel(neighbors) >= 1
                        pn = sample_n(neighbors, 1);
                        pp = sample_n(1:obj.n_pop, 2);
                        a = obj.P2(pp(1),:); b = obj.P2(pp(2),:); c = obj.P2(pn(1),:);
                    else
                        pidx = sample_n(1:obj.n_pop, 3);
                        a = obj.P2(pidx(1),:); b = obj.P2(pidx(2),:); c = obj.P2(pidx(3),:);
                    end
                    child = differential_evolution(obj, a, b, c, F_de);
                    child = gaussian_mutation(obj, child);
                    f = obj.problem.evaluate(child);
                    obj.Z = min(obj.Z, f);
                    if numel(neighbors) > 3
                        ur = neighbors;
                    else
                        ur = 1:obj.n_pop;
                    end
                    attempt2 = attempt2 + numel(ur);
                    for j = ur
                        if angle_dominate_select(obj, obj.P2(j,:), child, current_theta, j, epsilon)
                            obj.P2(j,:) = child;
                            srr2 = srr2 + 1;
                        end
                    end
                else
                    pidx = sample_n(1:obj.n_pop, 3);
                    child = differential_evolution(obj, obj.P2(pidx(1),:), obj.P2(pidx(2),:), obj.P2(pidx(3),:), F_de);
                    child = gaussian_mutation(obj, child);
                    f = obj.problem.evaluate(child);
                    obj.Z = min(obj.Z, f);
                    attempt2 = attempt2 + obj.n_pop;
                    for j = 1:obj.n_pop
                        if angle_dominate_select(obj, obj.P2(j,:), child, current_theta, j, epsilon)
                            obj.P2(j,:) = child;
                            srr2 = srr2 + 1;
                        end
                    end
                end
            end
        else
            % ================= 阶段2：基于环境选择的全局搜索 =================
            for i = 1:obj.n_pop
                pidx = sample_n(1:obj.n_pop, 2);
                c1 = crossover_sbx(obj, obj.P1(pidx(1),:), obj.P1(pidx(2),:), eta);
                c1 = mutation_poly(obj, c1, eta_m);
                f = obj.problem.evaluate(c1);
                obj.Z = min(obj.Z, f);
                child1{end+1} = c1;

                pidx = sample_n(1:obj.n_pop, 3);
                c2 = differential_evolution(obj, obj.P2(pidx(1),:), obj.P2(pidx(2),:), obj.P2(pidx(3),:), F_de);
                c2 = gaussian_mutation(obj, c2);
                f = obj.problem.evaluate(c2);
                obj.Z = min(obj.Z, f);
                child2{end+1} = c2;
            end
            [obj.P1, srr1] = environmental_selection(obj, obj.P1, child1, epsilon);
            [obj.P2, srr2] = environmental_selection(obj, obj.P2, child2, epsilon);
            attempt1 = obj.n_pop;
            attempt2 = obj.n_pop;
        end

        % ================= 权重自适应 =================
        if obj.n_obj >= 3 && mod(gen+1, 50) == 0
            if obj.max_gen*0.2 <= gen && gen <= obj.max_gen*0.8
                Fcur = obj.problem.evaluate(obj.best_P);
                try
                    if obj.n_pop >= 10
                        nclusters = min(10, floor(obj.n_pop/5));
                    else
                        nclusters = 2;
                    end
                    [dyn_n, ~] = compute_dynamic_n_replace(obj, Fcur, gen, nclusters, ...
                        recent_SRR_mean, prev_igd1, igd1);
                    [Wnew, ~, ~] = adapt_weights(obj.W, Fcur, nclusters, dyn_n, ...
                        deg2rad(8), deg2rad(6), gen);
                    obj.W = Wnew;
                    fprintf('第%d代: 权重自适应完成，动态替换%d个\n', gen+1, dyn_n);
                    obj.B = get_neighbors(obj);
                catch me
                    fprintf('权重自适应失败: %s，使用原有AW2方法\n', me.message);
                    aw2(obj);
                    obj.B = get_neighbors(obj);
                end
            end
        end

        % ================= 种群合并判断 =================
        if 0.2 <= alpha && alpha <= 0.8 && mod(gen+1, 20) == 0
            F1cmp = obj.problem.evaluate(obj.P1);
            try
                obj.epm.update(rows_to_cell(F1cmp));
            catch
            end
            F2 = obj.problem.evaluate(obj.P2);
            igdp2 = obj.igd(F2, true_pf);
            igdp1 = obj.igd(F1cmp, true_pf);
            fprintf('IGD of P1: %g, IGD of P2: %g\n', igdp1, igdp2);
            if igdp2 < igdp1
                merge_and_update(obj);
                F1a = obj.problem.evaluate(obj.P1);
                try
                    obj.epm.update(rows_to_cell(F1a));
                catch
                end
                obj.B = get_neighbors(obj);
            end
        end

        % ================= 算法参数更新 =================
        F1 = obj.problem.evaluate(obj.P1);
        try
            obj.epm.update(rows_to_cell(F1));
        catch
        end
        igd1 = obj.igd(F1, true_pf);
        obj.SRR = phase_switch(obj, srr1, srr2, alpha, attempt1, attempt2);
        obj.replace_count1 = srr1; obj.replace_count2 = srr2;
        obj.replace_attempt1 = attempt1; obj.replace_attempt2 = attempt2;
        obj.SRR_history(end+1) = obj.SRR;
        recent = obj.SRR_history(max(1, gen-9+1):gen+1);
        recent_SRR_mean = mean(recent);
        obj.rho = 0.0005 + 0.0095*(log10(gen+1)/3);

        nd_count = numel(obj.epm.ep);
        if ~isempty(prev_igd1) && ~isempty(prev_crowd1) && ~isempty(prev_igd2) ...
                && ~isempty(prev_crowd2) && ~isempty(prev_nd)
            reward = calculate_reward(obj, igd1, prev_igd1, crowd1, prev_crowd1, ...
                igd2, prev_igd2, crowd2, prev_crowd2, nd_count, prev_nd, recent_SRR_mean);
        else
            reward = 0;
        end

        % ================= PPO 训练 =================
        if gen > 0 && ~isempty(obj.prev_log_prob)
            obj.ppo.store_transition(obj.prev_state, obj.prev_action, ...
                obj.prev_reward, obj.prev_value, obj.prev_log_prob);
            obj.episode_step = obj.episode_step + 1;

            buffer_full = obj.ppo.buffer.ptr >= obj.ppo.buffer.buffer_size - 10;
            should_update = mod(obj.episode_step, obj.update_frequency) == 0 || buffer_full;
            if should_update
                obj.ppo.finish_path(value);
                if obj.ppo.buffer.ptr >= 10
                    ui = obj.ppo.update();
                    if ~isempty(ui)
                        fprintf('PPO Update (Step %d) - Policy Loss: %.4f, Value Loss: %.4f, Entropy: %.4f\n', ...
                            obj.episode_step, ui.policy_loss, ui.value_loss, ui.entropy);
                    end
                end
            end
        end

        obj.prev_state = state;
        obj.prev_action = action;
        obj.prev_value = value;
        obj.prev_log_prob = log_prob;
        obj.prev_reward = reward;

        prev_igd1 = igd1; prev_igd2 = igd2;
        prev_crowd1 = crowd1; prev_crowd2 = crowd2;
        prev_nd = nd_count;

        if igd1 < igd_t_min
            igd_t_min = igd1;
            obj.best_P = obj.P1;
        end
        igd_window(end+1) = igd1;
        if mod(gen+1, 10) == 0
            igd_values(end+1) = igd_t_min;
            fprintf('Gen: %d, MIN_IGD: %.6f, Phase: %d\n', gen, igd_t_min, int32(phase_condition));
            igd_window = [];
        end
    end

    % 最终轨迹与更新
    obj.ppo.finish_path(0);
    if obj.ppo.buffer.ptr > 0
        ui = obj.ppo.update();
        if ~isempty(ui)
            fprintf('Final PPO Update - Policy Loss: %.4f, Value Loss: %.4f, Entropy: %.4f\n', ...
                ui.policy_loss, ui.value_loss, ui.entropy);
        end
    end

    best_P = obj.best_P;
end

% ---------------- 本地辅助 ----------------
function c = rows_to_cell(M)
    c = cell(size(M,1), 1);
    for i = 1:size(M,1)
        c{i} = M(i,:);
    end
end

function idx = sample_n(arr, k)
    arr = arr(:).';
    k = min(k, numel(arr));
    p = randperm(numel(arr), k);
    idx = arr(p);
end

function x = fix_nan(x, d)
    if isnan(x), x = d; end
end
