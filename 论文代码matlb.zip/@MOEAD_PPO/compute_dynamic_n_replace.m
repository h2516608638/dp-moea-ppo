function [n_replace, labels] = compute_dynamic_n_replace(obj, F_current, gen, ...
        n_clusters, recent_SRR_mean, prev_igd, cur_igd) %#ok<INUSD>
    % 基于停滞度/分离度/簇均衡决定权重替换数量（采用无 sklearn 的回退口径）
    labels = [];
    min_r = 5;
    max_r = max(5, floor(0.4*obj.n_pop));

    if isempty(prev_igd) || isempty(cur_igd)
        igd_improve = 0;
    else
        igd_improve = max(0, prev_igd - cur_igd);
    end
    igd_gain = tanh(50*igd_improve);
    stagnation = 1 - igd_gain;

    if isempty(recent_SRR_mean)
        srr_mean = obj.SRR;
    else
        srr_mean = recent_SRR_mean;
    end
    srr_bp = min(max(10*abs(obj.SRR - srr_mean), 0), 1);

    varc = var(F_current, 0, 'all');
    bad_sep = 1/(1 + 10*varc);
    centroid = mean(F_current, 1);
    dists = sqrt(sum((F_current - centroid).^2, 2));
    imbalance_norm = tanh(std(dists));

    progress = gen / max(1, obj.max_gen);
    explore = 1 - 0.6*progress;

    base = 0.15 + 0.15*bad_sep + 0.10*imbalance_norm ...
        + 0.10*stagnation + 0.10*srr_bp;
    base = base * explore;
    base = min(max(base, 0.10), 0.40);
    n_replace = min(max(floor(base*obj.n_pop), min_r), max_r);
end
