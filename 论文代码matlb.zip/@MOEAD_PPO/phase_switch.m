function val = phase_switch(~, srr1, srr2, alpha, attempt1, attempt2)
    % 归一化替换率的加权平均
    if attempt1 > 0
        ps1 = srr1 / attempt1;
    else
        ps1 = 0;
    end
    if attempt2 > 0
        ps2 = srr2 / attempt2;
    else
        ps2 = 0;
    end
    val = ps1*alpha + ps2*(1-alpha);
end
