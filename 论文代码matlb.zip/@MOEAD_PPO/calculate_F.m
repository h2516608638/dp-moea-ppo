function finite_d = calculate_F(obj, F)
    % 返回过滤掉 inf 的拥挤距离
    cd = crowding_distance(obj, F);
    finite_d = cd(isfinite(cd));
end
