function fronts = epsilon_nds(obj, F, epsilon)
    % 基于 epsilon-支配的非支配排序，返回 fronts cell（覆盖全部解）
    n = size(F, 1);
    if n == 0
        fronts = {};
        return
    end
    dom_count = zeros(n, 1);
    dom_sol = cell(n, 1);
    for i = 1:n
        dom_sol{i} = [];
    end

    for i = 1:n
        for j = 1:n
            if i == j
                continue
            end
            if obj.epsilon_dominates(F(i,:), F(j,:), epsilon)
                dom_sol{i}(end+1) = j;
            elseif obj.epsilon_dominates(F(j,:), F(i,:), epsilon)
                dom_count(i) = dom_count(i) + 1;
            end
        end
    end

    first = find(dom_count == 0).';
    fronts = {first};
    assigned = false(n,1);
    assigned(first) = true;
    k = 1;

    while k <= numel(fronts) && ~all(assigned)
        next_front = [];
        fr = fronts{k};
        for p = fr
            qs = dom_sol{p};
            for q = qs
                dom_count(q) = dom_count(q) - 1;
                if dom_count(q) == 0 && ~assigned(q)
                    next_front(end+1) = q; %#ok<AGROW>
                    assigned(q) = true;
                end
            end
        end
        if isempty(next_front)
            break
        end
        fronts{end+1} = next_front; %#ok<AGROW>
        k = k + 1;
    end

    if ~all(assigned)
        rem = find(~assigned).';
        if ~isempty(rem)
            fronts{end+1} = rem;
        end
    end
    fronts = fronts(~cellfun(@isempty, fronts));
end
