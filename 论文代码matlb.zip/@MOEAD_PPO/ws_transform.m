function Wout = ws_transform(obj)
    % WS 变换：对权重按 1/w 归一化，零分量用 1e-12 替代
    w = obj.W;
    w(w <= 0) = 1e-12;
    inv_w = 1 ./ w;
    Wout = inv_w ./ sum(inv_w, 2);
end
