function D = pairwise_dist(A, B)
    % 欧氏距离矩阵（纯基础 MATLAB，不依赖统计工具箱）
    % D(i,j) = ||A(i,:)-B(j,:)||
    aa = sum(A.^2, 2);
    bb = sum(B.^2, 2);
    D = aa + bb.' - 2*(A * B.');
    D = sqrt(max(D, 0));
end
