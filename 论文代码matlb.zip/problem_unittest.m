%% DTLZ 问题单元测试：验证各问题 evaluate 与 pareto_front 的维度和有限性
clear; clc;
set_seed(1);
names = arrayfun(@(i) sprintf('dtlz%d', i), 1:7, 'UniformOutput', false);

for M = [2, 3]
    fprintf('\n----- M = %d -----\n', M);
    for k = 1:numel(names)
        nm = names{k};
        prob = DTLZProblem(nm, M);
        x = rand(4, prob.n_var);
        F = prob.evaluate(x);
        PF = prob.pareto_front(300);
        assert(isequal(size(F), [4, M]), 'evaluate 维度错误');
        assert(size(PF,2) == M, 'pareto_front 维度错误');
        assert(all(isfinite(F), 'all') && all(isfinite(PF), 'all'), '存在非有限值');
        igd = igd_metric(F, PF);
        fprintf('%s: D=%d, F [%d,%d], PF [%d,%d], sample IGD=%.4f\n', ...
            nm, prob.n_var, size(F,1), size(F,2), size(PF,1), size(PF,2), igd);
    end
end
fprintf('\nPROBLEM UNIT TEST OK\n');
