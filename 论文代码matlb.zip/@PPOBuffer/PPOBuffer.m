classdef PPOBuffer < handle
    % PPOBuffer  PPO 经验缓冲区，含 GAE(Generalized Advantage Estimation)
    properties
        buffer_size
        state_dim
        action_dim
        gamma = 0.99
        lam   = 0.95
        states
        actions
        rewards
        values
        log_probs
        advantages
        returns
        ptr = 0                 % 已存储经验数（下一条写入位置的 0-based 索引）
        path_start_idx = 0      % 当前轨迹起点（0-based）
    end

    methods
        function obj = PPOBuffer(buffer_size, state_dim, action_dim, gamma, lam)
            obj.buffer_size = buffer_size;
            obj.state_dim = state_dim;
            obj.action_dim = action_dim;
            if nargin >= 4, obj.gamma = gamma; end
            if nargin >= 5, obj.lam = lam; end
            obj.states    = zeros(buffer_size, state_dim);
            obj.actions   = zeros(buffer_size, action_dim);
            obj.rewards   = zeros(buffer_size, 1);
            obj.values    = zeros(buffer_size, 1);
            obj.log_probs = zeros(buffer_size, 1);
            obj.advantages = zeros(buffer_size, 1);
            obj.returns    = zeros(buffer_size, 1);
        end

        function store(obj, state, action, reward, value, log_prob)
            idx = obj.ptr + 1;
            obj.states(idx, :)    = state(:).';
            obj.actions(idx, :)   = action(:).';
            obj.rewards(idx)      = reward;
            obj.values(idx)       = value;
            obj.log_probs(idx)    = log_prob;
            obj.ptr = obj.ptr + 1;
        end

        function finish_path(obj, last_value)
            % 用 GAE 计算当前轨迹的优势与回报
            if obj.ptr == obj.path_start_idx
                return
            end
            s = obj.path_start_idx + 1;   % 1-based 切片起点
            e = obj.ptr;                  % 1-based 切片终点
            path_rewards = obj.rewards(s:e);
            path_values  = obj.values(s:e);
            n = numel(path_rewards);
            vals_aug = [path_values; last_value];
            deltas = path_rewards + obj.gamma * vals_aug(2:n+1) - vals_aug(1:n);
            adv = discount_cumsum(deltas, obj.gamma * obj.lam);
            obj.advantages(s:e) = adv;
            obj.returns(s:e) = adv + path_values;
            obj.path_start_idx = obj.ptr;
        end

        function data = get(obj)
            % 返回当前缓冲内容并标准化优势，随后重置指针
            if obj.ptr == 0
                data = [];
                return
            end
            idx = 1:obj.ptr;
            adv = obj.advantages(idx);
            adv_mean = mean(adv);
            adv_std = std(adv);
            if adv_std > 1e-8
                adv_norm = (adv - adv_mean) / adv_std;
            else
                adv_norm = zeros(size(adv));
            end
            data.states    = obj.states(idx, :);
            data.actions   = obj.actions(idx, :);
            data.rewards   = obj.rewards(idx);
            data.values    = obj.values(idx);
            data.log_probs = obj.log_probs(idx);
            data.advantages = adv_norm;
            data.returns    = obj.returns(idx);
            obj.ptr = 0;
            obj.path_start_idx = 0;
        end
    end
end

function result = discount_cumsum(x, discount)
    % 带折扣的累积和（对应 OpenAI Spinning Up 的 discount_cumsum）
    result = zeros(size(x));
    running = 0;
    for t = numel(x):-1:1
        running = x(t) + discount * running;
        result(t) = running;
    end
end
