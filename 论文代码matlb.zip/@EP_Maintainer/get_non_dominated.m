function non_dom = get_non_dominated(obj, solutions)
    % 对 cell 形式的解集合做非支配筛选，返回非支配解 cell
    non_dom = {};
    for ii = 1:numel(solutions)
        s = solutions{ii};
        ok = true;
        for jj = 1:numel(solutions)
            if ii == jj
                continue
            end
            other = solutions{jj};
            if numel(s) == numel(other) && all(s == other)
                continue
            end
            if obj.is_dominated(s, other)
                ok = false;
                break
            end
        end
        if ok
            non_dom{end+1} = s; %#ok<AGROW>
        end
    end
end
