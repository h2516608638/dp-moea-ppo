function tf = is_dominated(~, a, b)
    % 判断 a 是否被 b 支配（最小化）：b 所有目标 <= a 且至少一个 <
    tf = all(b <= a) && any(b < a);
end
