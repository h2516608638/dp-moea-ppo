function ep = update(obj, offspring)
    % 合并 EP 与后代（去重）-> 非支配筛选 -> 超规模小生境剔除
    combined = obj.ep;
    for ii = 1:numel(offspring)
        o = offspring{ii}(:).';
        dup = false;
        for jj = 1:numel(combined)
            s = combined{jj};
            if numel(s) == numel(o) && all(abs(o - s) <= 1e-8 + 1e-5*abs(s))
                dup = true;
                break
            end
        end
        if ~dup
            combined{end+1} = o; %#ok<AGROW>
        end
    end

    non_dom = obj.get_non_dominated(combined);
    if numel(non_dom) <= obj.n_ep
        obj.ep = non_dom;
    else
        obj.ep = obj.select_by_niche(non_dom);
    end
    ep = obj.ep;
end
