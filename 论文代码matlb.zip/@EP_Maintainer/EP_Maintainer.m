classdef EP_Maintainer < handle
    % EP_Maintainer  外部种群(External Population)维护器
    %   合并 -> 非支配筛选 -> 超规模时小生境剔除。
    properties
        core_pop_size
        n_ep            % EP 最大规模 = 1.5N
        ep = {}         % cell，每个元素为目标值行向量
        k = 3           % 近邻数
    end

    methods
        function obj = EP_Maintainer(core_pop_size)
            obj.core_pop_size = core_pop_size;
            obj.n_ep = floor(1.5 * core_pop_size);
        end
    end
end
