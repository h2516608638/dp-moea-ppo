function selected = select_by_niche(obj, solutions)
    % 小生境迭代剔除：每次删除拥挤度最大的解，直到规模 <= n_ep
    selected = solutions;
    while numel(selected) > obj.n_ep
        M = cell2mat(selected(:));          % [n,m]
        D = pairwise_dist(M, M);
        knn = knn_distance(D, obj.k);
        r = median(knn);
        crowd = crowding_degree(D, r);
        [~, idx] = max(crowd);
        selected(idx) = [];
    end
end

function knn = knn_distance(D, k)
    n = size(D, 1);
    knn = zeros(n, 1);
    for i = 1:n
        s = sort(D(i, :));
        if n <= k
            vals = s(s > 1e-8);
            knn(i) = mean(vals);
        else
            knn(i) = mean(s(2:k+1));        % 跳过自身（距离0）
        end
    end
end

function deg = crowding_degree(D, r)
    n = size(D, 1);
    deg = zeros(n, 1);
    for i = 1:n
        R = [];
        for j = 1:n
            if i == j
                continue
            end
            if D(i,j) <= r
                R(end+1) = D(i,j) / r; %#ok<AGROW>
            else
                R(end+1) = 1.0;       %#ok<AGROW>
            end
        end
        deg(i) = 1 - prod(R);
    end
end
