function W = generate_weights(M, N)
    % 生成 N 个单位权重向量 [N,M]
    % 2 目标线性；其余用 Das-Dennis 单纯形点并均匀选取/补齐到 N
    if M == 2
        t = linspace(0, 1, N).';
        W = [t, 1 - t];
        return
    end

    p = 1;
    while nchoosek(p+M-1, M-1) < N
        p = p + 1;
    end
    P = simplex_points(M, p);
    total = size(P, 1);

    if total >= N
        sel = unique(round(linspace(1, total, N)));
        W = P(sel, :);
        if size(W, 1) < N
            W = fill_random(W, M, N);
        end
    else
        W = fill_random(P, M, N);
    end
end

function W = fill_random(W, M, N)
    % 用随机单纯形点补齐到 N
    while size(W, 1) < N
        r = rand(1, M);
        r = r / sum(r);
        if ~any(all(abs(W - r) < 1e-10, 2))
            W = [W; r];
        end
    end
end

function P = simplex_points(M, p)
    n = nchoosek(p+M-1, M-1);
    c = nchoosek(1:p+M-1, M-1);
    aug = [zeros(n,1), c, (p+M)*ones(n,1)];
    P = diff(aug, 1, 2) - 1;
    P = P / p;
end
