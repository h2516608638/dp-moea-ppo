%% 冒烟测试：小规模、M=2（不触发 drnd），验证初始化/进化/PPO更新/环境选择可运行
clear; clc;
set_seed(7);

problem = DTLZProblem('dtlz2', 2);
N = 20; MAX_GEN = 120; n_neighbors = 10;
W  = generate_weights(2, N);
P1 = generate_population(problem, N);
P2 = generate_population(problem, N);
true_pf = problem.pareto_front(500);

ppo = PPO(8, 3, [1,15,15], 3e-4, 0.99, 0.95, 0.2, 256, 32, 10);
algo = MOEAD_PPO(problem, P1, P2, W, ppo, N, MAX_GEN, n_neighbors);

[best_P, igd_curve, igd_t_min] = algo.run(true_pf);
fprintf('\nSMOKE TEST OK, final IGD = %.6f, curve points = %d\n', igd_t_min, numel(igd_curve));

% 验证 HV 蒙特卡洛（不依赖工具箱）
F_best = problem.evaluate(best_P);
F_norm = F_best ./ (1.1*max(F_best,[],1) + 1e-10);
hv = hv_monte_carlo(F_norm, 20000, 42);
fprintf('SMOKE TEST HV = %.6f\n', hv);
