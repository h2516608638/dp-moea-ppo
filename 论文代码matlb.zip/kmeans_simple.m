function [centers, assign, clusters] = kmeans_simple(X, k, max_iter)
    % 简易 KMeans（欧氏距离），返回簇中心、分配向量与每簇索引 cell
    if nargin < 3, max_iter = 50; end
    n = size(X, 1);
    k = min(k, max(1, n));
    init_idx = randperm(n, k);
    centers = X(init_idx, :);

    for it = 1:max_iter
        D = pairwise_dist(X, centers);
        [~, assign] = min(D, [], 2);
        newc = centers;
        for j = 1:k
            mask = assign == j;
            if any(mask)
                newc(j, :) = mean(X(mask, :), 1);
            end
        end
        if all(abs(newc - centers) <= 1e-8, 'all')
            centers = newc;
            break
        end
        centers = newc;
    end

    D = pairwise_dist(X, centers);
    [~, assign] = min(D, [], 2);
    clusters = cell(1, k);
    for j = 1:k
        clusters{j} = find(assign == j);
    end
end
